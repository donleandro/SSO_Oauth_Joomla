DROP TABLE IF EXISTS `#__miniorange_oauth_config`;
DROP TABLE IF EXISTS `#__miniorange_oauth_customer`;