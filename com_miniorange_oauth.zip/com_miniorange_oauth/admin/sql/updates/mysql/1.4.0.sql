
ALTER TABLE `#__miniorange_oauth_config` ADD COLUMN  `in_header_or_body` varchar(255) NOT NULL default 'both';
