ALTER TABLE `#__miniorange_oauth_customer` ADD COLUMN  `uninstall_feedback` int(2) NOT NULL;



