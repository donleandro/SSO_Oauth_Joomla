ALTER TABLE `#__miniorange_oauth_config` ADD COLUMN  `httpreferer` VARCHAR(255) NOT NULL;
ALTER TABLE `#__miniorange_oauth_config` ADD COLUMN  `userslim` VARCHAR(255) NOT NULL;
ALTER TABLE `#__miniorange_oauth_config` ADD COLUMN  `usrlmt` VARCHAR(255) NOT NULL;
